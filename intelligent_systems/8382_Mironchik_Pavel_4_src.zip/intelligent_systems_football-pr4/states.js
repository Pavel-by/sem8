const Utils = require("./utils")
const Coords = require("./coordinates")

class BallAnalyzer {
    constructor(agent, mem) {
        this.agent = agent
        this.mem = mem
        this._wasKicked = false
        if (!this._hasBall() || this._getBallAge() > 0)
            this._update()
    }

    isReady() {
        return this._hasBall()
    }

    wasKicked() {
        return this._wasKicked
    }

    estimateCoords(depth) {
        return this._estimateCoords(depth)
    }

    estimateVelocity(depth) {
        return this._estimateVelocity(depth)
    }

    getAge() {
        return this._getBallAge()
    }

    canKick() {
        let playerSize = this.agent.params.player_size
        let kickableMargin = this.agent.params.kickable_margin
        return Coords.distance(this.estimateCoords(0), this.agent.position.coords) < kickableMargin + playerSize / 2
    }

    _update() {
        if (!this.agent.hear.isPlayOn() && !this.agent.hear.isKickOffAlly()) this._clear()
        this._wasKicked = false
        let oldEstimate = this.isReady() ? this.estimateCoords(5) : null
        let visibleBallInfo = null
        for (let obj of this.agent.position.objects) {
            if (obj.isBall) {
                visibleBallInfo = obj
                break
            }
        }
        let position = Utils.calculateObjectPositioning(this.agent, visibleBallInfo)
        if (!position) return
        let info = {
            coords: position.coords,
            velocity: this._calculateVisibleVelocity(visibleBallInfo)
        }
        this._updateBall(info)
        if (oldEstimate !== null) {
            let newEstimate = this.estimateCoords(5)
            this._wasKicked = Coords.distance(oldEstimate, newEstimate) > 4
        }
    }

    _calculateVisibleVelocity(visibleBallInfo) {
        if (!Utils.isNumber(visibleBallInfo?.dirChange) || !Utils.isNumber(visibleBallInfo?.distChange) || !visibleBallInfo?.coords)
            return null;

        let relativeDirection = Utils.rotateVector({ x: 1, y: 0 }, visibleBallInfo.direction)
        let relativeCoords = Utils.multVector(relativeDirection, visibleBallInfo.distance)
        let nextRelativeCoords = Utils.multVector(relativeDirection, visibleBallInfo.distance + visibleBallInfo.distChange)
        nextRelativeCoords = Utils.rotateVector(nextRelativeCoords, visibleBallInfo.dirChange)
        let playerRelativeSpeed = this.agent.sense.relativeSpeed()
        let ballRelativeVelocity = {
            x: nextRelativeCoords.x - relativeCoords.x + playerRelativeSpeed.x,
            y: nextRelativeCoords.y - relativeCoords.y + playerRelativeSpeed.y
        }
        let zeroDirection = Utils.vectorDirection(this.agent.position.zeroVec, { x: 1, y: 0 })
        let ballAbsoluteVelocity = Utils.rotateVector(ballRelativeVelocity, zeroDirection)
        let ballMaxSpeed = this.agent.params.ball_speed_max
        let ballSpeed = Utils.vectorLength(ballAbsoluteVelocity)
        if (ballMaxSpeed < ballSpeed) {
            ballAbsoluteVelocity = {
                x: ballAbsoluteVelocity.x * ballMaxSpeed / ballSpeed,
                y: ballAbsoluteVelocity.y * ballMaxSpeed / ballSpeed,
            }
        }
        return ballAbsoluteVelocity
    }

    _clear() {
        this.mem.delete("BallAnalyzer.ball")
    }

    _updateBall(ball) {
        this.mem.updateValue("BallAnalyzer.ball", ball)
    }

    _hasBall() {
        return this.mem.has("BallAnalyzer.ball")
    }

    _getBall() {
        return this.mem.getValue("BallAnalyzer.ball")
    }

    _getBallAge() {
        return this.mem.getAge("BallAnalyzer.ball")
    }

    _estimateVelocity(depth) {
        let ball = this._getBall()
        let velocity = ball.velocity
        if (ball.velocity == null) return { x: 0, y: 0 }
        let ballAge = this._getBallAge()
        depth += ballAge
        let decay = this.agent.params.ball_decay
        return {
            x: velocity.x * decay ** depth,
            y: velocity.y * decay ** depth
        }
    }

    _estimateCoords(depth) {
        let ball = this._getBall()
        let ballAge = this._getBallAge()
        depth += ballAge
        if (ball.velocity == null || depth <= 0) return ball.coords
        let velocity = ball.velocity
        let decay = this.agent.params.ball_decay
        let progression = (1 - decay ** depth) / (1 - decay)
        return {
            x: ball.coords.x + velocity.x * progression,
            y: ball.coords.y + velocity.y * progression
        }
    }
}

class PathAnalyzer {
    constructor(agent, ballAnalyzer) {
        this.agent = agent
        this.ball = ballAnalyzer
    }

    estimateAgentShortestPath(power = 70) {
        return this.estimateShortestPath({
            coords: this.agent.position.coords,
            zeroVec: this.agent.position.zeroVec,
        }, power)
    }

    estimateShortestPath(from, power = 70) {
        let depth = 0
        while (true) {
            let ballCoords = this.ball.estimateCoords(depth)
            let time = this._estimatePathTime(from, ballCoords, power)
            if (time <= depth) {
                return {
                    coords: ballCoords,
                    fromCoords: from.coords,
                    time: depth,
                    power: power,
                }
            }
            depth++
        }
    }

    _estimatePathTime(from, toCoords, power) {
        if (!power || power < 30) {
            console.trace("too small power, are you sure? " + power)
            power = 30
        }
        let coords = from.coords
        if (Coords.distance(coords, toCoords) < 0.5) return 0;
        let time = 0
        if (from.zeroVec) {
            let zeroVec = Utils.normalize(from.zeroVec)
            let angle = Math.abs(Utils.vectorDirection(zeroVec, Utils.vectorFromPoints(coords, toCoords)))
            if (angle > 10) time++
        } else time++
        let distance = Coords.distance(coords, toCoords)
        let speed = this.agent.params.player_speed_max * power / 100
        time += Math.ceil((distance / speed) * 1.25)
        return time
    }
}

class PlayersAnalyzer {
    constructor(agent, pathAnalyzer, mem) {
        this.agent = agent
        this.path = pathAnalyzer
        this.mem = mem
        this._prepare()
    }

    findShortestAlly() {
        return this._findShortest(this._allies)
    }

    findShortestEnemy() {
        return this._findShortest(this._enemies)
    }

    getAllies() {
        return this._allies
    }

    getEnemies() {
        return this._enemies
    }

    _findShortest(players) {
        if (players.length == 0) return null
        let shortest = players[0]
        for (let player of players)
            if (player.path.time < shortest.path.time)
                shortest = player
        return shortest
    }

    _prepare() {
        this._allies = []
        this._enemies = []
        for (let obj of this.agent.position.objects) {
            if (obj.isAlly) {
                let player = this._constructPlayer(obj)
                if (player) {
                    this._allies.push(player)
                    if (player.uniformNumber)
                        this.mem.updateValue(`ally_${player.uniformNumber}`, player)
                }
            }
            if (obj.isEnemy) {
                let player = this._constructPlayer(obj)
                if (player) {
                    this._enemies.push(player)
                    if (player.uniformNumber)
                        this.mem.updateValue(`enemy_${player.uniformNumber}`, player)
                }
            }
        }
        for (let i = 1; i <= 11; i++) {
            let allyKey = `ally_${i}`
            let enemyKey = `enemy_${i}`
            if (this.mem.getAge(allyKey) < 5 && this.mem.getAge(allyKey) > 0)
                this._allies.push(this.mem.getValue(allyKey))
            if (this.mem.getAge(enemyKey) < 5 && this.mem.getAge(enemyKey) > 0)
                this._enemies.push(this.mem.getValue(enemyKey))
        }
    }

    _constructPlayer(info) {
        let position = Utils.calculateObjectPositioning(this.agent, info)
        if (!position) return null
        let zeroVec = null
        if (Utils.isNumber(info.bodyFacingDir)) {
            zeroVec = Utils.rotateVector(this.agent.position.zeroVec, info.bodyFacingDir)
        }
        let shortestPath = this.path.estimateShortestPath({
            coords: position.coords,
            zeroVec: zeroVec,
        }, 70)
        return {
            coords: position.coords,
            zeroVec: zeroVec,
            path: shortestPath,
            uniformNumber: info.uniformNumber,
        }
    }
}

class SchemaHelper {
    constructor(agent, center, radius) {
        this.agent = agent
        this.center = center
        this.radius = radius
    }

    estimateAllyRoleCoords(role) {
        let coords;
        if (role == 'attacker_front_middle') coords = { x: this.radius + 5, y: 0 }
        if (role == 'attacker_front_top') coords = { x: this.radius + 5, y: 20 }
        if (role == 'attacker_front_bottom') coords = { x: this.radius + 5, y: -20 }

        if (!coords) {
            console.log("AAAA unknown role " + role)
            return this.center
        }

        if (this.agent.side == 'r')
            coords.x *= -1

        coords.x += this.center.x
        return coords
    }

    calculateAllyRoleAttackTarget(role) {
        let coords;
        if (role == 'attacker_front_middle') coords = { x: 52.5, y: 0 }
        if (role == 'attacker_front_top') coords = { x: 52.5 - 15, y: 20 }
        if (role == 'attacker_front_bottom') coords = { x: 52.5 - 15, y: -20 }

        if (!coords) {
            console.log("AAAA unknown role " + role)
            return this.center
        }

        if (this.agent.side == 'r')
            coords.x *= -1

        coords.x += this.center.x
        return coords
    }
}

class StateTree {
    constructor(agent) {
        this.agent = agent
        this.mem = new Memory()
        this.states = {
            "init": (t) => CommonStates.stateInit(t, t.data),
            "find_ball": (t) => CommonStates.stateFindBall(t, t.data),
            "dribble": (t) => CommonStates.stateDribble(t, t.data),
            "move": (t) => CommonStates.stateMove(t, t.data),
            "kick_ally": (t) => CommonStates.stateKickAlly(t, t.data),

            "team_attack": (t) => AttackerTeamStates.stateTeamAttack(t, t.data),
            "team_dribble": (t) => AttackerTeamStates.stateTeamDribble(t, t.data),
            "team_follow": (t) => AttackerTeamStates.stateTeamFollow(t, t.data),

            "select_goal": (t) => GoalStates.stateSelectGoal(t, t.data),
            "process_goal": (t) => GoalStates.stateProcessGoal(t, t.data),

            "goalie": (t) => GoalieStates.stateGoalie(t, t.data),
            "goalie_intercept": (t) => GoalieStates.stateGoalieIntercept(t, t.data),
            "goalie_kick_out": (t) => GoalieStates.stateGoalieKickOut(t, t.data),
            "goalie_catch": (t) => GoalieStates.stateGoalieCatch(t, t.data),

            "schema": (t) => SchemaStates.stateSchema(t, t.data),
            "schema_kick": (t) => SchemaStates.stateSchemaKick(t, t.data),
            "schema_kick_off": (t) => SchemaStates.stateSchemaKickOff(t, t.data),
            "schema_move_default": (t) => SchemaStates.stateSchemaMoveDefault(t, t.data),
            "schema_attack": (t) => SchemaStates.stateSchemaAttack(t, t.data),
            "schema_give_pass": (t) => SchemaStates.stateSchemaGivePass(t, t.data),
        }
        this.data = {}
    }

    makeCmd() {
        this._cmd = null
        this.callState("init")
        this.mem.increaseAge()
        return this._cmd
    }

    callState(state) {
        this.states[state](this)
    }

    finish(cmd) {
        this._cmd = cmd
    }

    finishTurn(turn) {
        this.finish({ n: 'turn', v: turn })
    }

    finishDash(power) {
        this.finish({ n: 'dash', v: power })
    }

    finishKick(power, direction = 0) {
        this.data.init.ball._clear()
        this.mem.updateValue('finishKick', null)
        this.finish({ n: 'kick', v: [power, direction] })
    }

    finishCatch(direction) {
        this.finish({ n: 'catch', v: direction })
    }

    finishMove(coords) {
        if (!Array.isArray(coords))
            coords = [coords.x, coords.y]
        this.finish({ n: 'move', v: coords })
    }
}

const CommonStates = {
    stateInit(tree, data) {
        data.init ??= {}
        data.init.agent = tree.agent
        data.init.ball = new BallAnalyzer(data.init.agent, tree.mem)
        data.init.params = data.init.agent.params

        let ball = data.init.ball
        if (!ball.isReady() || ball.getAge() > 7) {
            return tree.callState("find_ball")
        }

        data.init.path = new PathAnalyzer(data.init.agent, data.init.ball)
        data.init.players = new PlayersAnalyzer(data.init.agent, data.init.path, tree.mem)
        data.findBall = {
            estimatedBallCoords: ball.estimateCoords(0)
        }
        return tree.callState("schema")
    },
    stateFindBall(tree, data) {
        data.findBall ??= {}
        let estimatedDirection = null

        if (data.findBall.estimatedBallCoords) {
            let ballPosition = Utils.calculateObjectPositioning(data.init.agent, { coords: data.findBall.estimatedBallCoords })
            if (Utils.isNumber(ballPosition.direction))
                estimatedDirection = ballPosition.direction
        }
        if (Utils.isNumber(data.findBall.estimatedBallDirection)) {
            estimatedDirection = data.findBall.estimatedBallDirection
        }
        data.findBall = {}
        if (estimatedDirection != null)
            return tree.finishTurn(estimatedDirection)
        return tree.finishTurn(90)
    },
    stateDribble(tree, data) {
        let target = Utils.calculateObjectPositioning(data.init.agent, data.dribble.target)
        let power = data.dribble.power ?? 70
        data.dribble = {}

        let kickMargin = data.init.params.kickable_margin
        let agentCoords = data.init.agent.position.coords
        let ballCoords = data.init.ball.estimateCoords(0)
        let distanceToBall = Coords.distance(agentCoords, ballCoords)

        if (distanceToBall < kickMargin)
            return tree.finishKick(35 * Math.sqrt(power / 100), target.direction)

        if (distanceToBall < 2) {
            data.move = {
                target: { coords: ballCoords },
                power: power
            }
            return tree.callState("move")
        }

        let pathAnalyzer = data.init.path
        let optimalPath = pathAnalyzer.estimateShortestPath({
            coords: data.init.agent.position.coords,
            zeroVec: data.init.agent.position.zeroVec,
        }, power)
        data.move = {
            target: { coords: optimalPath.coords },
            power: power,
        }
        return tree.callState("move")
    },
    stateMove(tree, data) {
        let target = Utils.calculateObjectPositioning(data.init.agent, data.move.target)
        let power = data.move.power ?? 70
        data.move = {}

        let A = target.distance
        let B = 0.5
        let C = Math.sqrt(A ** 2 + B ** 2)
        let availableAngle = Math.abs(Math.asin(B / C)) * 180 / Math.PI
        if (Math.abs(target.direction) > Math.max(5, availableAngle))
            return tree.finishTurn(target.direction)
        return tree.finishDash(power)
    },
    stateKickAlly(tree, data) {
        let target = Utils.calculateObjectPositioning(tree.agent, data.kickAlly.target)
        let power = Math.min(100, target.distance / 40 * 100)
        return tree.finishKick(power, target.direction)
    }
}

const AttackerTeamStates = {
    stateTeamAttack(tree, data) {
        let target = Utils.calculateObjectPositioning(data.init.agent, { coords: Utils.calculateEnemyGatesCoords(data.init.agent) })
        let ball = data.init.ball
        let hear = tree.agent.hear



        let agentCoords = data.init.agent.position.coords
        let kickMargin = data.init.params.kickable_margin
        let distanceToBall = Coords.distance(agentCoords, ball.estimateCoords(0))
        if (distanceToBall < kickMargin && target.distance < 25) {
            let movedTarget = {
                coords: {
                    x: target.coords.x,
                    y: target.coords.y + (Math.random() * 10 - 5)
                }
            }
            movedTarget = Utils.calculateObjectPositioning(data.init.agent, movedTarget)
            return tree.finishKick(100, movedTarget.direction)
        }

        data.teamDribble = {
            target: target
        }
        return tree.callState("team_dribble")
    },
    stateTeamDribble(tree, data) {
        let target = data.teamDribble.target
        data.teamDribble = {}
        let players = data.init.players
        let path = data.init.path
        let agent = data.init.agent
        let ball = data.init.ball

        let agentPath = path.estimateShortestPath({
            coords: agent.position.coords,
            zeroVec: agent.position.zeroVec,
        })
        let ally = players.findShortestAlly()
        if (ally && agentPath.time > ally.path.time) {
            let ballCoords = ball.estimateCoords(0)
            ally.isBallOwner = true
            data.teamFollow = {
                coords: ballCoords,
                direction: Utils.normalize(Utils.vectorFromPoints(ballCoords, target.coords)),
            }
            return tree.callState("team_follow")
        }

        data.dribble = {
            target: target
        }
        return tree.callState("dribble")
    },
    stateTeamFollow(tree, data) {
        const FollowDistance = 10
        const FollowAngle = 30
        const FollowErrorRadius = 2

        let players = data.init.players
        let targetCoords = data.teamFollow.coords
        let targetDirection = Utils.normalize(data.teamFollow.direction)
        data.teamFollow = {}
        let agentCoords = data.init.agent.position.coords
        let leftCoords = Utils.sumVector(Utils.multVector(Utils.rotateVector(targetDirection, -(180 - FollowAngle)), FollowDistance), targetCoords)
        let rightCoords = Utils.sumVector(Utils.multVector(Utils.rotateVector(targetDirection, 180 - FollowAngle), FollowDistance), targetCoords)
        let preferredPosition = null
        let secondaryPosition = null

        if (Coords.distance(leftCoords, agentCoords) > Coords.distance(rightCoords, agentCoords)) {
            preferredPosition = "right"
        } else {
            preferredPosition = "left"
        }

        let key = "team_follow_side"
        if (tree.mem.has(key) && tree.mem.getAge(key) < 15) {
            preferredPosition = tree.mem.getValue(key)
        }
        secondaryPosition = preferredPosition == "left" ? "right" : "left"

        let isPositionFree = function (preferrecCoords, secondaryCoords, agentCoords) {
            let allies = players.getAllies()
            for (let ally of allies) {
                if (ally.isBallOwner) continue
                let allyDistancePreferred = Coords.distance(ally.coords, preferrecCoords)
                let allyDistanceSecondary = Coords.distance(ally.coords, secondaryCoords)
                let agentDistance = Coords.distance(agentCoords, preferrecCoords)

                if (allyDistancePreferred < allyDistanceSecondary && agentDistance > allyDistancePreferred)
                    return false
            }
            return true
        }
        let preferredCoords = preferredPosition === "left" ? leftCoords : rightCoords
        let secondaryCoords = secondaryPosition === "left" ? leftCoords : rightCoords
        let selectedCoords = null
        if (isPositionFree(preferredCoords, secondaryCoords, agentCoords)) {
            tree.mem.updateValue(key, preferredPosition)
            selectedCoords = preferredCoords
        } else if (isPositionFree(secondaryCoords, preferredCoords, agentCoords)) {
            tree.mem.updateValue(key, secondaryPosition)
            selectedCoords = secondaryCoords
        }

        if (!selectedCoords || Coords.distance(selectedCoords, agentCoords) < FollowErrorRadius)
            return tree.callState("find_ball")

        data.move = {
            target: { coords: selectedCoords },
            power: Coords.distance(agentCoords, selectedCoords) > 10 ? 100 : 70
        }
        tree.callState("move")
    },
}

const GoalieStates = {
    stateGoalie(tree, data) {
        let ball = data.init.ball
        let players = data.init.players
        let path = data.init.path
        let gatesCoords = Utils.calculateAllyGatesCoords(data.init.agent)
        let ballVector = Utils.normalize(Utils.vectorFromPoints(gatesCoords, ball.estimateCoords(0)))
        ballVector = Utils.multVector(ballVector, 7.5)
        ballVector.x /= 4
        ballVector.y *= 0.8
        let optimalCoords = Utils.sumVector(gatesCoords, ballVector)

        if (Coords.distance(ball.estimateCoords(0), gatesCoords) < 10)
            return tree.callState("goalie_intercept")

        let shortestEnemy = players.findShortestEnemy()
        //let shortestAlly = players.findShortestAlly()
        let agentPath = path.estimateShortestPath({
            coords: data.init.agent.position.coords,
            zeroVec: data.init.agent.position.zeroVec,
        }, 100)

        if (Coords.distance(agentPath.coords, gatesCoords) < 15) {
            return tree.callState("goalie_intercept")
        }

        let agentCoords = data.init.agent.position.coords
        if (Coords.distance(agentCoords, optimalCoords) > 0.5) {
            data.move = {
                target: { coords: optimalCoords },
                power: 70
            }
            return tree.callState("move")
        }

        return tree.callState("find_ball")
    },
    stateGoalieIntercept(tree, data) {
        let mem = tree.mem
        let agentCoords = data.init.agent.position.coords
        let ballCoords = data.init.ball.estimateCoords(0)
        let gatesCoords = Utils.calculateAllyGatesCoords(data.init.agent)
        if (data.init.ball.canKick())
            return tree.callState("goalie_kick_out")
        let ballRelativeCoords = {
            x: Math.abs(ballCoords.x - gatesCoords.x),
            y: Math.abs(ballCoords.y - gatesCoords.y),
        }
        let catchAllowed = ballRelativeCoords.x < 15 && ballRelativeCoords.y < 19
        if (catchAllowed && Coords.distance(ballCoords, agentCoords) < data.init.params.catchable_area_l)
            return tree.callState("goalie_catch")

        let storedCoords = mem.getAge('goalieIntercept.coords') < 5 ? mem.getValue('goalieIntercept.coords') : null
        if (!storedCoords || Coords.distance(storedCoords, agentCoords) < 0.5) {
            let path = data.init.path
            let agentPath = path.estimateShortestPath({
                coords: agentCoords,
                zeroVec: data.init.agent.position.zeroVec,
            }, 100)
            storedCoords = agentPath.coords
            mem.updateValue('goalieIntercept.coords', storedCoords)
        }

        data.move = {
            target: { coords: storedCoords },
            power: 100,
        }
        return tree.callState("move")
    },
    stateGoalieKickOut(tree, data) {
        let agentSide = data.init.agent.side
        let gatesTop = agentSide == 'l' ? Coords.fglt : Coords.fgrt
        let gatesBottom = agentSide == 'l' ? Coords.fglb : Coords.fgrb
        let agentCoords = data.init.agent.position.coords
        let agentZero = data.init.agent.position.zeroVec
        /*let directionInGates = function(point, v) {
            let d1 = Utils.vectorDirection(Utils.vectorFromPoints(point, gatesTop), v)
            let d2 = Utils.vectorDirection(Utils.vectorFromPoints(point, gatesBottom), v)
            return d1 * d2 < 0
        }
        let enemyOnDirection = function(point, v) {
            let enemies = tree.manager.enemies
            for (let enemy of enemies) {
                if (!enemy?.coords) continue
                let enemyDirection = Utils.vectorFromPoints(point, enemy.coords)
                if (Math.abs(Utils.vectorDirection(enemyDirection, v)) < 10) return true
            }
            return false
        }*/
        let freeDirectionVector = Utils.normalize(Utils.vectorFromPoints(agentCoords, { x: 0, y: 10 }))
        let freeDirection = Utils.vectorDirection(freeDirectionVector, agentZero)
        return tree.finishKick(100, freeDirection)
    },
    stateGoalieCatch(tree, data) {
        let agent = data.init.agent
        let ballPosition = Utils.calculateObjectPositioning(agent, { coords: data.init.ball.estimateCoords(0) })
        let ballDirection = ballPosition.direction
        return tree.finishCatch(ballDirection)
    }
}

const GoalStates = {
    stateSelectGoal(tree, data) {
        if (data.init.agent.isGoalie)
            return tree.callState("goalie")

        const DribbleErrorRadius = 3

        let agent = data.init.agent
        let ball = data.init.ball
        let goals = agent.goals
        data.selectGoal ??= {}
        let currentGoalIndex = data.selectGoal.currentIndex ?? 0

        let isGoalAchieved = function (goal) {
            if (goal.type === "dribble") {
                let goalCoords = goal.coords
                let ballCoords = ball.estimateCoords(0)
                return Coords.distance(goalCoords, ballCoords) < DribbleErrorRadius
            }
            if (goal.type === "attack") {
                // TODO
                return false
            }
            console.log(`Unknown goal ${goal.type}`)
            return true
        }

        let isAchievingGoal = function (goal) {
            if (goal.type === "dribble") {
                let goalCoords = goal.coords
                let ballCoords = ball.estimateCoords(0)
                let goalDirectionVector = Utils.vectorFromPoints(ballCoords, goalCoords)
                let ballVelocity = ball.estimateVelocity(0)
                if (Utils.vectorLength(ballVelocity) < 0.6) return false
                let diff = Utils.vectorDirection(ballVelocity, goalDirectionVector)
                return Math.abs(diff) < 20
            }
            return false
        }

        while (isGoalAchieved(goals[currentGoalIndex])) {
            currentGoalIndex = (currentGoalIndex + 1) % goals.length
        }

        let goal = goals[currentGoalIndex]
        let nextGoal = goals[(currentGoalIndex + 1) % goals.length]
        if (isAchievingGoal(nextGoal) && !isAchievingGoal(goal)) {
            goal = nextGoal
            currentGoalIndex = (currentGoalIndex + 1) % goals.length
        }

        data.processGoal = {
            goal: goal
        }
        data.selectGoal.currentIndex = currentGoalIndex
        return tree.callState("process_goal")
    },
    stateProcessGoal(tree, data) {
        let goal = data.processGoal.goal

        if (goal.type === "dribble") {
            data.teamDribble = {
                target: { coords: goal.coords }
            }
            return tree.callState("team_dribble")
        }

        if (goal.type === "attack") {
            return tree.callState("team_attack")
        }

        console.log(`unknown goal ${goal.type}`)
        return tree.callState('find_ball')
    }
}

const SchemaStates = {
    stateSchema(tree, data) {
        const SchemaRadius = 5

        let mem = tree.mem
        let hear = tree.agent.hear
        data.schema ??= {}

        if (hear.canMove()) {
            data.schema.center = null
            return tree.callState('schema_move_default')
        }

        let oldCenterX = mem.getValue('schema.centerX')
        if (!oldCenterX) {
            if (tree.agent.side == 'l')
                oldCenterX = -SchemaRadius
            else
                oldCenterX = SchemaRadius
        }
        let ballCoords = tree.data.init.ball.estimateCoords(0);

        if (Math.abs(oldCenterX - ballCoords.x) > SchemaRadius) {
            let sign = ballCoords.x > oldCenterX ? 1 : -1
            let diff = (Math.abs(ballCoords.x - oldCenterX) - SchemaRadius) * sign
            oldCenterX += diff
        }

        mem.updateValue('schema.centerX', oldCenterX)
        data.schema.center = {
            x: oldCenterX,
            y: 0,
        }
        data.schema.radius = SchemaRadius
        data.schema.helper = new SchemaHelper(tree.agent, data.schema.center, data.schema.radius)

        if (tree.agent.role == 'goalie')
            return tree.callState('goalie')

        if (tree.agent.role == 'statist') {
            /*let coords = { x: -52.5, y: 8 }
            if (tree.agent.side == 'r')
                coords.x *= -1
            data.move = {
                target: { coords: coords }
            }*/
            return tree.finish(null)
        }

        if (hear.isKickOffAlly())
            return tree.callState('schema_kick_off')

        if (!hear.isPlayOn())
            return tree.callState('find_ball')

        return tree.callState('schema_attack')
    },
    stateSchemaMoveDefault(tree, data) {
        let baseCoords = null;
        let role = tree.agent.role;
        if (role == 'goalie') baseCoords = [-50, 0]
        if (role == 'attacker_front_middle') baseCoords = [-5, 0]
        if (role == 'attacker_front_top') baseCoords = [-5, 20]
        if (role == 'attacker_front_bottom') baseCoords = [-5, -20]
        if (role == 'statist') baseCoords = [-52.5, -8]
        let coords = tree.agent.position.coords
        if (Coords.distance(baseCoords, coords) > 3)
            return tree.finishMove(baseCoords)
        return tree.callState('find_ball')
    },
    stateSchemaKickOff(tree, data) {
        let role = tree.agent.role;
        if (role != 'attacker_front_middle')
            return tree.callState('find_ball')

        let distance = Coords.distance({ x: 0, y: 0 }, tree.agent.position.coords)
        if (distance < 0.5) {
            let selectedRole = Math.random() > 0.5 ? 'attacker_front_top' : 'attacker_front_bottom'
            let targetPosition = Utils.calculateObjectPositioning(
                tree.agent,
                { coords: data.schema.helper.estimateAllyRoleCoords(selectedRole) })
            data.kickAlly = {
                target: targetPosition
            }
            return tree.callState('kick_ally')
        }
        data.move = {
            target: { coords: { x: 0, y: 0 } }
        }
        return tree.callState('move')
    },
    stateSchemaAttack(tree, data) {
        let mem = tree.mem
        let ball = data.init.ball
        if (ball.canKick()) {
            return tree.callState('schema_kick')
        }

        let lastGoal = mem.getValue('schemaAttack.goal')
        if (ball.getAge() == 0 || lastGoal == 'intercept') {
            let path = data.init.path
            let players = data.init.players
            let agentPath = path.estimateAgentShortestPath()
            let enemyPath = players.findShortestEnemy()?.path
            let allyPath = players.findShortestAlly()?.path
            if (!allyPath || allyPath.time >= agentPath.time) {
                mem.updateValue('schemaAttack.goal', 'intercept')
                let storedCoords = mem.getAge('schemaAttack.interceptCoords') < 5 ? mem.getValue('schemaAttack.interceptCoords') : null
                if (!storedCoords || Coords.distance(tree.agent.position.coords, storedCoords) < 0.5) {
                    storedCoords = agentPath.coords
                    mem.updateValue('schemaAttack.interceptCoords', storedCoords)
                }
                data.move = {
                    target: {coords: storedCoords},
                    power: !enemyPath || agentPath.time > enemyPath.time + 2 ? 70 : 100
                }
                return tree.callState('move')
            }
        }

        mem.updateValue('schemaAttack.goal', 'move')
        let optimalCoords = data.schema.helper.estimateAllyRoleCoords(tree.agent.role)
        let optimalCoordsDistance = Coords.distance(optimalCoords, tree.agent.position.coords)
        if (optimalCoordsDistance < 3) {
            return tree.callState('find_ball')
        }
        data.move = {
            target: { coords: optimalCoords },
            power: optimalCoordsDistance < 10 ? 70 : 100,
        }
        return tree.callState('move')
    },
    stateSchemaKick(tree, data) {
        let mem = tree.mem
        let gatesCoords = Utils.calculateEnemyGatesCoords(tree.agent)
        let ball = data.init.ball
        if (Coords.distance(gatesCoords, ball.estimateCoords(0)) < 30) {
            if (mem.getAge('finishKick') > 30 || Math.random() > 1) { //todo
                let movedTarget = {
                    coords: {
                        x: gatesCoords.x,
                        y: gatesCoords.y + (Math.random() * 10 - 5)
                    }
                }
                movedTarget = Utils.calculateObjectPositioning(data.init.agent, movedTarget)
                return tree.finishKick(100, movedTarget.direction)
            }

            data.schemaGivePass = {
                frontOnly: true
            }
            return tree.callState('schema_give_pass')
        }

        data.dribble = {
            target: { coords: data.schema.helper.calculateAllyRoleAttackTarget(tree.agent.role) },
        }
        return tree.callState('dribble')
    },
    stateSchemaGivePass(tree, data) {
        let frontOnly = data.schemaGivePass?.frontOnly == true // todo
        data.schemaGivePass = {}
        let selectedRole = Utils.selectRandom([
            'attacker_front_top',
            'attacker_front_middle',
            'attacker_front_bottom'
        ], null, [tree.agent.role])
        let rolePosition = Utils.calculateObjectPositioning(tree.agent, { coords: data.schema.helper.estimateAllyRoleCoords(selectedRole) })
        let allies = data.init.players.getAllies()
        if (allies.length == 0) {
            return tree.finishTurn(rolePosition.direction)
        }
        let ind = Math.floor(Math.random() * allies.length)
        let ally = allies[ind]
        data.kickAlly = {
            target: { coords: ally.coords }
        }
        return tree.callState('kick_ally')
    }
}

class Memory {
    constructor() {
        this._data = new Map()
    }

    increaseAge() {
        for (let key of this._data.keys()) {
            this._data.get(key).age++
        }
    }

    updateValue(key, value) {
        this._data.set(key, {
            value: value,
            age: 0
        })
    }

    getValue(key) {
        return this._data.get(key)?.value
    }

    getAge(key) {
        return this._data.get(key)?.age ?? 10000
    }

    has(key) {
        return this._data.has(key)
    }

    delete(key) {
        this._data.delete(key)
    }
}

module.exports = StateTree;